package br.ufrpe.joanam2.conexaojdbc;

import org.junit.Test;

public class SingletonConexaoTest {

	@Test
	public void conectarTest() {
		SingletonConexao.getConexao();
	}
}
