package br.ufrpe.joanam2.dao;

public class UsuarioDaoTest {

}
