package br.ufrpe.joanam2.business;

public class UsuarioCadastro {

}
