package br.ufrpe.joanam2.controller.bean;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import br.ufrpe.joanam2.business.dao.GenericoDao;
import br.ufrpe.joanam2.business.model.Usuario;

@ViewScoped
@ManagedBean(name = "usuarioBean")
public class UsuarioBean {
	
	private Usuario usuario = new Usuario();
	private GenericoDao<Usuario> genericoDao = new GenericoDao<Usuario>();
	
	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public GenericoDao<Usuario> getGenericoDao() {
		return genericoDao;
	}

	public void setGenericoDao(GenericoDao<Usuario> genericoDao) {
		this.genericoDao = genericoDao;
	}

	public String salvar() {
		genericoDao.salvar(usuario);
		return "";
	}

}
